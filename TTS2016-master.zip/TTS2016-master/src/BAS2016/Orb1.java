package BAS2016;
import org.newdawn.slick.Image;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.geom.Rectangle;
import org.newdawn.slick.geom.Shape;
public class Orb1 {
   private int locationX;
   private int locationY;
   private int size;
   public boolean iceIsTrue;
   public boolean fireIsTrue;
   private boolean isVisible;
   Image orbpic;
   Shape hitbox;
   private int startX, startY, width = 16, height = 16;
   private int x, y;
    float hitboxX = x + 8f;
    float hitboxY = y + 8f;
    public Shape rect = new Rectangle(getHitboxX(),
            getHitboxY(), width, height);
   public Orb1(int x, int y) throws SlickException{
       this.isVisible= false;
       this.locationX = x;
       this.locationY = y;
       this.orbpic = new Image ("res/car.png");
       this.hitbox = new Rectangle (x,y,32,32);
    } 
   
   public void setX(int a){
       this.x = a; 
   }  
   public void setY(int a){
       this.x = a;
   }
    public int getLocationX() {
        return locationX;
    }
    public void setLocationX(int locationX) {
        this.locationX = locationX;
    }
    public int getLocationY() {
        return locationY;
    }
    public void setLocationY(int locationY) {
        this.locationY = locationY;
    }
    public int getSize() {
        return size;
    }
    public void setSize(int size) {
        this.size = size;
    }
    public boolean isIsVisible() {
        return isVisible;
    }
    public void setIsVisible(boolean isVisible) {
        this.isVisible = isVisible;
    }
    public Image getOrbpic() {
        return orbpic;
    }
    public void setOrbpic(Image orbpic) {
        this.orbpic = orbpic;
    }
    public Shape getHitbox() {
        return hitbox;
    }
    public void setHitbox(Shape hitbox) {
        this.hitbox = hitbox;
    }
    public float getHitboxX() {
        return x + 18f;
    }

    public float getHitboxY() {
        return y + 18f;
    }
    public void setplayershitboxX() {
        hitboxX = getHitboxX();
    }

    public void setplayershitboxY() {
        hitboxY = getHitboxY();
    }
    public void setlocation(int a, int b){
     //   this.setLocationX((int)Player.x+16);
       // this.setLocationY((int)Player.y-16);
    } 
}

