<?xml version="1.0" encoding="UTF-8"?>
<tileset name="tile2map64" tilewidth="64" tileheight="64">
 <image source="tile2map64.png" width="256" height="21120"/>
</tileset>
